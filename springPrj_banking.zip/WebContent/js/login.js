$(document).ready(function(){
	$("#checkId").click(function(){
		var ID = $.trim($("#insertmemID").val());

		if (ID=="") {
			alert("아이디를 입력하세요.");
		} else {
			$.ajax({
				url : '../MemberController?cmd=checkId',
				type : 'Post',
				dataType : "text",
				data : $('input').serialize() ,
				success : function(data) {
					if ($.trim(data) == "1") {
						alert("아이디 중복");
						$("#count").val(1);
					} else {
						alert("아이디 사용가능");
						$("#count").val(0);
					}
				}
			})
		}
	});

	$(".logout").click(function(){
		$.ajax({
			url : 'MemberController?cmd=logout',
			type : 'Post',
			success : function(data) {
				alert("로그아웃 되었습니다.");
				location.replace('index.jsp');
			}
		})
	});

	$("#memberInsert").click(function(){
		var count = $("#count").val();
	
		if(count == 1){
			alert("ID 중복체크를 하세요!");
		} else {
			$.ajax({
				url : '../MemberController?cmd=memberInsert',
				type : 'Post',
				cache : false, 
				data : $('input').serialize(),
				success : function(data) {
					location.replace('../index.jsp');
				}
			})	
		}
	});

	$("#list").click(function(){
		$.ajax({
			url : 'MemberController?cmd=selectAllMember',
			type : 'Post',
			cache : false, 
			success : function(data) {
				var data = JSON.parse(data);
				$("#loginResult").html("");
				$.each(data.member, function(index, member) {
					var items = [];
					items.push("아이디 : "+member.memID);
					items.push(" 이름 : "+member.name);
					items.push(" 연락처 : "+member.phone);
					items.push(" 주소 : "+member.address);
					$("#loginResult").append("회원"+items+"<br>");
				});
			}, 
			error : function(data) {
				alert("조회실패");
			}
		})
	});

	$("#select").click(function(){
		$.ajax({
			url : 'MemberController?cmd=selectMember',
			type : 'Post',
			data : $("#select1").serialize(),
			success : function(data) {
				$("#result").html("");
				$(".memID").val("");
				$("#name").val("");
				$("#phone").val("");
				$("#address").val("");
				var data = JSON.parse(data);

				if (data.msg != undefined) {
					$("#result").append(data.msg);
				} else {
					$(".memID").val(data.memId);
					$("#name").val(data.name);
					$("#phone").val(data.phone);
					$("#address").val(data.address);
				}
			}, 
			error : function(data) {
				alert("조회실패");
			}
		})
	});

	$("#update").click(function(){
		alert($("#info").serialize());
		$.ajax({
			url : 'MemberController?cmd=updateMember',
			type : 'Post',
			data : $("#info").serialize() ,
			success : function(data) {
				$("#result").html("");
				if (data.msg != undefined) { 
					var data = JSON.parse(data);
					$.each(data, function(key, val) {
						$("#result").append(key+" "+val+"<br>");
					});
					alert("수정완료");	
				} else {
					alert(data.msg);
				}
			}
		})	
	});

	$("#delete").click(function(){
		if ($.trim($("#delete1").val())=="") {
			alert("아이디를 입력하세요");
		} else {
			$.ajax({
				url : 'MemberController?cmd=deleteMember',
				type : 'Post',
				data : $("#delete1").serialize(),
				success : function(data) {
					alert("삭제완료");			
				}
			})	
		}
	});

	$("#submit").click(function(){

		if ($.trim($("#memID").val())=="") {
			alert("아이디를 입력하세요");
		} else {
			$.ajax({
				url : 'MemberController?cmd=loginMember',
				type : 'Post',
				data : $('input').serialize(),
				success : function(data) {
					if (data == "") {
						alert("로그인 성공");	
						location.replace('index.jsp');
					} else {
						alert(data);			
					}
				}
			})	
		}
	});
});

function initMap() {
    var uluru = {lat: 37.481613, lng: 126.881839};
    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 18,
      center: uluru
    });
    var marker = new google.maps.Marker({
      position: uluru,
      map: map
    });
  }


;(function ($, window, undefined) {//Bootstrap Hover Dropdown
    var $allDropdowns = $();

    $.fn.dropdownHover = function (options) {
        if('ontouchstart' in document) return this;

        $allDropdowns = $allDropdowns.add(this.parent());

        return this.each(function () {
            var $this = $(this),
                $parent = $this.parent(),
                defaults = {
                    delay: 500,
                    hoverDelay: 0,
                    instantlyCloseOthers: true
                },
                data = {
                    delay: $(this).data('delay'),
                    hoverDelay: $(this).data('hover-delay'),
                    instantlyCloseOthers: $(this).data('close-others')
                },
                showEvent   = 'show.bs.dropdown',
                hideEvent   = 'hide.bs.dropdown',
                // shownEvent  = 'shown.bs.dropdown',
                // hiddenEvent = 'hidden.bs.dropdown',
                settings = $.extend(true, {}, defaults, options, data),
                timeout, timeoutHover;

            $parent.hover(function (event) {

                if(!$parent.hasClass('open') && !$this.is(event.target)) {
                    return true;
                }

                openDropdown(event);
            }, function () {
                window.clearTimeout(timeoutHover)
                timeout = window.setTimeout(function () {
                    $this.attr('aria-expanded', 'false');
                    $parent.removeClass('open');
                    $this.trigger(hideEvent);
                }, settings.delay);
            });

            $this.hover(function (event) {
                if(!$parent.hasClass('open') && !$parent.is(event.target)) {
                    return true;
                }

                openDropdown(event);
            });

            $parent.find('.dropdown-submenu').each(function (){
                var $this = $(this);
                var subTimeout;
                $this.hover(function () {
                    window.clearTimeout(subTimeout);
                    $this.children('.dropdown-menu').show();
                    $this.siblings().children('.dropdown-menu').hide();
                }, function () {
                    var $submenu = $this.children('.dropdown-menu');
                    subTimeout = window.setTimeout(function () {
                        $submenu.hide();
                    }, settings.delay);
                });
            });

            function openDropdown(event) {
                if($this.parents(".navbar").find(".navbar-toggle").is(":visible")) {
                    return;
                }

                window.clearTimeout(timeout);
                window.clearTimeout(timeoutHover);
                
                timeoutHover = window.setTimeout(function () {
                    $allDropdowns.find(':focus').blur();

                    if(settings.instantlyCloseOthers === true)
                        $allDropdowns.removeClass('open');
                    
                    window.clearTimeout(timeoutHover);
                    $this.attr('aria-expanded', 'true');
                    $parent.addClass('open');
                    $this.trigger(showEvent);
                }, settings.hoverDelay);
            }
        });
    };

    $(document).ready(function () {
        $('[data-hover="dropdown"]').dropdownHover();
    });
})(jQuery, window);

