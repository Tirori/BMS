package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONObject;
import org.json.simple.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Response;

import service.MemberService;
import vo.MemberVO;

@WebServlet(name = "memberController", urlPatterns = { "/memberController" })
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService ms;
	private MemberVO vo;

	public MemberController() {
		super();
		ms = new MemberService();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		memberProcess(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		memberProcess(request, response);
	}

	protected void memberProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String cmd = request.getParameter("cmd");

		if (cmd.equals("insertMember")) {
			insertMember(request, response);
		} else if (cmd.equals("selectAllMember")) {
			selectAllMember(request, response);
		} else if (cmd.equals("updateMember")) {
			updateMember(request, response);
		} else if (cmd.equals("deleteMember")) {
			deleteMember(request, response);
		} else if (cmd.equals("idCheck")) {
			idCheck(request, response);
		} else if (cmd.equals("selectMember")) {
			selectMember(request, response);
		} else if (cmd.equals("loginMember")) {
			loginMember(request, response);
		} else if (cmd.equals("logoutMember")) {
			logoutMember(request, response);
		}  else if (cmd.equals("isLogin")) {
			isLogin(request, response);
		}
	}

	private void selectMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		JSONObject obj = new JSONObject();

		try {
			String memID = request.getParameter("memID");
			String pwd = request.getParameter("pwd");
			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			String address = request.getParameter("address");

			MemberVO vo = new MemberVO(memID, pwd, name, phone, address);
			List list = new ArrayList();
			list.add(vo);
			
			ms.selectMember(list);
					
			obj.put("memID", vo.getMemID());
			obj.put("pwd", vo.getPwd());
			obj.put("name", vo.getName());
			obj.put("phone", vo.getPhone());
			obj.put("address", vo.getAddress());

			if (vo.getResult().equals("0")) {
				out.println(obj);
			}
			
			if (vo.getResult().equals("0")) {

			} else {
				
				out.println("no");
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	private void deleteMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			String memID = (String) request.getSession().getAttribute("memID");
			String pwd = (String) request.getSession().getAttribute("pwd");

			MemberVO vo = new MemberVO(memID, pwd);

			List list = new ArrayList();
			list.add(vo);

			ms.deleteMember(list);

			if (vo.getResult() != null) {
				request.getSession().invalidate();
				out.println("yes");

			} else {

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	public void loginMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		try {
			String memID = request.getParameter("memID");
			String pwd = request.getParameter("pwd");
			MemberVO vo = new MemberVO(memID, pwd);

			List list = new ArrayList();
			list.add(vo);

			ms.loginMember(list);
			System.out.println(vo.getResult());
			
			if (vo.getResult().equals("0")) {
				
				request.getSession().setAttribute("memID", vo.getMemID());
				request.getSession().setAttribute("pwd", vo.getPwd());
				out.println("y");

			} else if (vo.getResult().equals("2")) {
				out.println("np");
			} else if (vo.getResult().equals("1")) {
				out.println("n");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	public void insertMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		try {
			String memID = request.getParameter("memID");
			String pwd = request.getParameter("pwd");
			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			String address = request.getParameter("address");

			MemberVO vo = new MemberVO(memID, pwd, name, phone, address);
			List list = new ArrayList();
			list.add(vo);

			ms.insertMember(list);

			if (vo.getResult().equals("0")) {
				out.println("yes");
			} else {
				out.println("no");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	public void idCheck(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		try {

			String memID = request.getParameter("memID");
			String pwd = request.getParameter("pwd");
			MemberVO vo = new MemberVO(memID, pwd);
			List list = new ArrayList();
			list.add(vo);

			ms.idCheck(list);

			if (vo.getResult().equals("1")) {
				out.println("Y");
			} else {

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	public void selectAllMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		

		try {

			JSONArray jArray= new JSONArray();
			List list = new ArrayList();
		
			ms.selectAllMember(list);
			
			vo =(MemberVO)list.get(0);
			System.out.println(" ��"+vo.getMemID());
			vo =(MemberVO)list.get(1);
			System.out.println(" ������"+vo.getMemID());
			
			for(int i=0; i <list.size(); i++) {
			JSONObject obj= new JSONObject();
			MemberVO vo = (MemberVO) list.get(i);
			obj.put("ID",vo.getMemID());
			obj.put("password",vo.getPwd());
			obj.put("name",vo.getName());
			obj.put("phone",vo.getPhone());
			obj.put("address",vo.getAddress());
			jArray.add(obj);
			}
			
			if (list.size() > 0) {
				out.println(jArray);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	public void updateMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		try {

			String memID = request.getParameter("memID");
			System.out.println("1 " + memID);
			String pwd = request.getParameter("pwd");

			String name = request.getParameter("name");
			String phone = request.getParameter("phone");
			String address = request.getParameter("address");

			MemberVO vo = new MemberVO(memID, pwd, name, phone, address);
			List list = new ArrayList();
			list.add(vo);
			ms.updateMember(list);
	

			if (vo.getResult().equals("0")) {
				out.println("yes");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	protected void logoutMember(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().invalidate();

	}
	public void isLogin(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String memID = (String)request.getSession().getAttribute("memID");
		boolean login = memID == null ? false : true;
		PrintWriter out = response.getWriter();
		System.out.println(memID);
		if(login) {
			out.println("y");
		} else {

		}
	}
	
}
