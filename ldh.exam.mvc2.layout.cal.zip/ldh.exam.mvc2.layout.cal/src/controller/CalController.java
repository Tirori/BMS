package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import service.CalService;
import service.MemberService;
import vo.CalExceptionMsgVO;
import vo.CalVO;
import vo.MemberVO;

@WebServlet("/calController")
public class CalController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CalService cs;
	private CalVO vo;

	public CalController() {
		super();
		cs = new CalService();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		calProcess(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		calProcess(request, response);
	}

	protected void calProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String cmd = request.getParameter("cmd");
		if (cmd.equals("cal")) {
			cal(request, response);
		}

	}

	public void cal(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		JSONObject obj = new JSONObject();
		String op1 = request.getParameter("op1");
		String op = request.getParameter("op");
		String op2 = request.getParameter("op2");
//		System.out.println(op1);
//		System.out.println(op);
//		System.out.println(op2);
		List list = new ArrayList();
		CalVO vo = new CalVO(op1, op, op2);
		list.add(vo);
		list.add(new CalExceptionMsgVO());
		
		try {
			cs.cal(list);
			System.out.println(op1);
			obj.put("op1", vo.getOp1());
			obj.put("op", vo.getOp());
			obj.put("op2", vo.getOp2());
			obj.put("result", vo.getResult());
			out.println(obj);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

}
