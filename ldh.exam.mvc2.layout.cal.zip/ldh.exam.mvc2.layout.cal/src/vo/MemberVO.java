package vo;

public class MemberVO {
	private String memID;
	private String pwd;
	private String name;
	private String phone;
	private String address;
	private String result;
	
	public MemberVO() {

	}
	
	public MemberVO(String memID) {
		this.memID   = memID;

	}
	
	public MemberVO(String memID, String pwd) {
		this.memID   = memID;
		this.pwd     = pwd;
	}
	
	public MemberVO(String memID, String pwd, String name, String phone, String address) {
		this.memID   = memID;
		this.pwd     = pwd;
		this.name    = name;
		this.phone   = phone;
		this.address = address;
		
	}

	public String getMemID() {
		return memID;
	}

	public void setMemID(String memID) {
		this.memID = memID;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
}
