package vo;

public class CalExceptionMsgVO {
	private String msgAddZero;
	private String msgSubZero;
	private String msgMulOne;
	private String msgDivOne;
	
	public void setMsgAddZero(String msg) {
		this.msgAddZero = msg;
	}
	public String getMsgAddZero() {
		return msgAddZero;
	}
	
	public void setMsgSubZero(String msg) {
		this.msgSubZero = msg;
	}
	
	public String getMsgSubZero() {
		return msgSubZero;
	}
	
	public void setMsgMulOne(String msg) {
		this.msgMulOne = msg;
	}
	public String getMsgMulOne() {
		return msgMulOne;
	}
	
	public void setMsgDivOne(String msg) {
		this.msgDivOne = msg;
	}
	public String getMsgDivOne() {
		return msgDivOne;
	}
}
