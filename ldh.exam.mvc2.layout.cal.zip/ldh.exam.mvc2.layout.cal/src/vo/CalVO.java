package vo;

public class CalVO {
	public static final String ADD = "add";
	public static final String SUB = "sub";
	public static final String MUL = "mul";
	public static final String DIV = "div";

	private String op1;
	private String op;
	private String op2;
	private String result;
	private String dbResult;

	public CalVO(String op1, String op, String op2) {
		this.op1 = op1;
		this.op = op;
		this.op2 = op2;
	}

	public String getOp1() {
		return op1;
	}

	public String getOp() {
		return op;
	}

	public String getOp2() {
		return op2;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getDbResult() {
		return dbResult;
	}

	public void setDbResult(String dbResult) {
		this.dbResult = dbResult;
	}
}
