package exception;

public class MulOneException extends Exception{
	public MulOneException(String msg) {
		super(msg);
	}
}
