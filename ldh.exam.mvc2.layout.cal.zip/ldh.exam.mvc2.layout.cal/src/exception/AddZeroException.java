package exception;

public class AddZeroException extends Exception{
	public AddZeroException(String msg) {
		super(msg);
	}
}
