package exception;

public class DivOneException extends Exception{
	public DivOneException(String msg) {
		super(msg);
	}
}
