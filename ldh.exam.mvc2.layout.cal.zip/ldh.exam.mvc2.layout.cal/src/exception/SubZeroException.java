package exception;

public class SubZeroException extends Exception {
	public SubZeroException(String msg) {
		super(msg);
	}
}
