package service;

import java.util.List;

import entity.MemberEntity;
import vo.MemberVO;

public class MemberService {
	private MemberEntity me;
	
	public MemberService() {
		me = new MemberEntity();
	}
	public void insertMember(List list) {
		me.insertMember(list);
	}
	public void loginMember(List list) {
		me.loginMember(list);
	}
	public void idCheck(List list) {
		me.idCheck(list);
	}
	public void deleteMember(List list) {
		me.deleteMember(list);
	}
	public void updateMember(List list) {
		me.updateMember(list);
	}
	public void selectMember(List list) {
		me.selectMember(list);
	}
	public void selectAllMember(List list) {
		me.selectAllMember(list);
	}

}



