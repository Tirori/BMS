package service;

import java.util.List;

import entity.CalEntity;
import exception.AddZeroException;
import exception.DivOneException;
import exception.MulOneException;
import exception.SubZeroException;
import vo.CalExceptionMsgVO;
import vo.CalVO;

public class CalService {
	private CalEntity ce;
	private CalExceptionMsgVO eMvo;
	private CalVO vo;
	private String result;

	public CalService() {
		ce = new CalEntity();
	}

	public void cal(List list) {
		vo = (CalVO) list.get(0);
		eMvo = (CalExceptionMsgVO) list.get(1);

		String op1 = vo.getOp1();
		String op = vo.getOp();
		String op2 = vo.getOp2();


		try {
			if (op.equals("+")) {
				if (op1.equals("0") || op2.equals("0")) {
					eMvo.setMsgAddZero(ce.errorMsg(95));
					throw new AddZeroException(eMvo.getMsgAddZero());
				} else {
					result = (Float.parseFloat(op1) + Float.parseFloat(op2) + "");

				}
			} else if (op.equals("-")) {
				if (op1.equals("0") || op2.equals("0")) {
					eMvo.setMsgSubZero(ce.errorMsg(96));
					throw new SubZeroException(eMvo.getMsgSubZero());
				} else {
					result = (Float.parseFloat(op1) - Float.parseFloat(op2) + "");

				}
			} else if (op.equals("*")) {
				if (op1.equals("1") || op2.equals("1")) {
					eMvo.setMsgMulOne(ce.errorMsg(97));
					throw new MulOneException(eMvo.getMsgMulOne());
				} else {
					result = (Float.parseFloat(op1) * Float.parseFloat(op2) + "");
				}
			} else if (op.equals("/")) {
				if (op2.equals("1")) {
					eMvo.setMsgDivOne(ce.errorMsg(98));
					throw new DivOneException(eMvo.getMsgDivOne());
				} else {
					result = (Float.parseFloat(op1) / Float.parseFloat(op2) + "");
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		vo.setResult(result);
		ce.insert(list);

	}
}
