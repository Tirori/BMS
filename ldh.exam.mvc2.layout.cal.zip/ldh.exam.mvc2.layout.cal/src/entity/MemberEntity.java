package entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import vo.MemberVO;

public class MemberEntity {

	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	private List list;
	private DataSource ds;
	private Context ctx;

	public MemberEntity() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// �α���
	public void loginMember(List list) {
		MemberVO vo = (MemberVO) list.get(0);

		String memID = "";
		String pwd = "";

		try {
			con = ds.getConnection();
			String query = "SELECT * FROM tb_mem where memID = ?";

			stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getMemID());

			rs = stmt.executeQuery();

			while (rs.next()) {
				memID = rs.getString("memID").trim();
				pwd = rs.getString("pwd").trim();

			}

			if (vo.getMemID().equals(memID) && vo.getPwd().equals(pwd)) {
				vo.setResult("0");

			} else if (!pwd.equals(vo.getPwd())) {

				vo.setResult("1");
			} else if (!memID.equals(vo.getMemID())) {
				vo.setResult("2");
			}
			System.out.println(vo.getResult());

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}

			}

		}

	}

	// ȸ������
	public void insertMember(List list) {
		try {
			MemberVO vo = (MemberVO) list.get(0);
			con = ds.getConnection();

			String query = "insert into tb_mem values(seq_mem.nextval,?,?,?,?,?)";
			stmt = con.prepareStatement(query);

			//stmt.setString(1, new String(vo.getMemID().getBytes("8859_1"), "UTF-8"));
			stmt.setString(1, vo.getMemID());
			stmt.setString(2, vo.getPwd());
			//stmt.setString(3, new String(vo.getName().getBytes("8859_1"), "UTF-8"));
			stmt.setString(3, vo.getName());
			stmt.setString(4, vo.getPhone());
			//stmt.setString(5, new String(vo.getAddress().getBytes("8859_1"), "UTF-8"));
			stmt.setString(5, vo.getAddress());
			stmt.executeUpdate();

			vo.setResult("0");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	// ���̵� Ȯ��
	public void idCheck(List list) {
		MemberVO vo = (MemberVO) list.get(0);
		String memID = "";

		try {
			con = ds.getConnection();

			String query = "select memID from tb_mem where memID= ?";
			stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getMemID());

			System.out.println(vo.getMemID());
			rs = stmt.executeQuery();

			while (rs.next()) {
				memID = rs.getString("memID").trim();
			}
			if (memID.equals(vo.getMemID())) {
				vo.setResult("0");
			} else {
				vo.setResult("1");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

		}
	}

	// ȸ�����
	public void selectAllMember(List list) {

		this.list = list;

		String memID = "";
		String pwd = "";
		String name = "";
		String phone = "";
		String address = "";

		try {
			con = ds.getConnection();
			String query = "SELECT * FROM tb_mem ORDER BY memID";
			stmt = con.prepareStatement(query);

			rs = stmt.executeQuery();

			while (rs.next()) {

				memID = rs.getString("memID").trim();
				pwd = rs.getString("pwd").trim();
				name = rs.getString("name").trim();
				phone = rs.getString("phone").trim();
				address = rs.getString("address").trim();
				MemberVO vo = new MemberVO(memID, pwd, name, phone, address);
				System.out.println(memID);
				list.add(vo);
			}

			System.out.println(list.size());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}

			}

		}

	}

	public void updateMember(List list) {
		try {
			MemberVO vo = (MemberVO) list.get(0);
			con = ds.getConnection();

			String query = "update tb_mem set pwd= ?, name=?, phone=?, address=? where memID = ?";
			stmt = con.prepareStatement(query);
			System.out.println(vo.getPwd());

			stmt.setString(1, vo.getPwd());
			stmt.setString(2,vo.getName());
			stmt.setString(3, vo.getPhone());
			stmt.setString(4, vo.getAddress());
			stmt.setString(5, vo.getMemID());

			stmt.executeUpdate();
			vo.setResult("0");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}

			}
		}

	}

	public void deleteMember(List list) {

		MemberVO vo = (MemberVO) list.get(0);

		try {
			con = ds.getConnection();

			String query = "delete tb_mem where memID=? and pwd=?";
			stmt = con.prepareStatement(query);
			stmt.setString(1, vo.getMemID());
			stmt.setString(2, vo.getPwd());
			stmt.executeUpdate();

			vo.setResult("0");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void selectMember(List list) {

		MemberVO vo = (MemberVO) list.get(0);

		String memID = "";
		String pwd = "";
		String name = "";
		String phone = "";
		String address = "";

		try {
			con = ds.getConnection();

			String query = "SELECT * FROM tb_mem where memID=?";
			stmt = con.prepareStatement(query);
			//stmt.setString(1, new String(vo.getMemID().getBytes("8859_1"), "UTF-8"));
			stmt.setString(1,vo.getMemID());

			rs = stmt.executeQuery();

			while (rs.next()) {

				memID = rs.getString("memID").trim();
				pwd = rs.getString("pwd").trim();
				name = rs.getString("name").trim();
				phone = rs.getString("phone").trim();
				address = rs.getString("address").trim();

				vo.setMemID(memID);
				vo.setPwd(pwd);
				vo.setName(name);
				vo.setPhone(phone);
				vo.setAddress(address);

			}

			vo.setResult("0");
			System.out.println(vo.getResult());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}

			}

		}

	}

}
