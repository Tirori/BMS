package entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import vo.CalVO;
import vo.MemberVO;

public class CalEntity {

	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	private List list;
	private DataSource ds;
	private Context ctx;

	public CalEntity() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void insert(List list) {
		CalVO vo = (CalVO) list.get(0);
		try {
			con = ds.getConnection();
			String query = "insert into tb_cal(id,op1,op,op2,result) values(seq_cal.nextval,?,?,?,?)";
			stmt = con.prepareStatement(query);
			stmt.setFloat(1, Float.parseFloat(vo.getOp1()));
			stmt.setString(2, vo.getOp());
			stmt.setFloat(3, Float.parseFloat(vo.getOp2()));
			stmt.setString(4, vo.getResult());

			stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}

	}

	public void select(List list) {

		CalVO vo = (CalVO) list.get(0);
		String dbResult = null;
		
		try {
			con = ds.getConnection();
			String query = "SELECT * FROM tb_cal";
			stmt = con.prepareStatement(query);
	
			stmt.setString(1, vo.getResult());
			rs = stmt.executeQuery();

			while (rs.next()) {
				dbResult = rs.getString("result").trim();
				vo.setDbResult(dbResult);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}

			}

		}

	}

	public String errorMsg(int p) {

		String msg = null;
		try {
			con = ds.getConnection();
			String query = "SELECT * FROM tb_msg where code =" + p;
			stmt = con.prepareStatement(query);
			rs = stmt.executeQuery();

			while (rs.next()) {
				msg = rs.getString("msg").trim();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return msg;
	}
}
