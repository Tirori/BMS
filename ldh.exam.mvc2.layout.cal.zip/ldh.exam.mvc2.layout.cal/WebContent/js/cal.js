$(document).ready(function() {
	var op1 = "";
	var op = "";
	var op2 = "";
	var state = "";
	var num = "";

	$(".calNumber").click(function() {
		num += $(this).val();
		if (op != null && state == null) {
			$("#display").val("");
			$("#display").val(num);
			state = 0;
		} else {
			$("#display").val(num);
		}
	});
	$(".op").click(function() {
		num = "";
		op1 = Number($("#display").val());
		op = $(this).val();
		state = null;
	});
	$(".clr").click(function() {
		$("#display").fadeOut("fast", function() {
			$("#display").fadeIn("fast");
		});
		$("#display").val("");
		op = null;
		state = null;
		num = "";
	});
	$(".equal").click(function() {
		var formData = $("#operator").serialize(); // controller input data
		var formAction = $("#operator").attr("action");// controller
		// 주소,버튼//액션주소
		if (state == 0) {
			op2 = Number($("#display").val());
			$("#display").val("");
		} else {
			$("#display").val("");
		}

		$.ajax({
			type : "POST",
			url : formAction + "?cmd=cal",
			data : {
				"op1" : op1,
				"op" : op,
				"op2" : op2
			},
				
			success : function(data) {
				if ($.trim(data) != "") {
					var rs = JSON.parse(data);
					$("#display").val(rs.result);
				
				}
			}, error:function(request,status,error){
		        alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		       }
		    
		});
		op1 = Number($("#display").val());

		$("#display").animate({
			fontSize : '2.4em'
		}, "fast", function() {
			$("#display").animate({
				fontSize : '3.5em'
			}, "fast");
		});

		state = 1;
		num = "";
	});
});
