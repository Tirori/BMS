$(document).ready(function() {

	$("#idCheck").click(function() {
		var formData = $("#memForm").serialize();
		alert(formData);
		if ($("#memID").val()=="") {
			alert("아이디를 입력하세요");
		} else {
			$.ajax({
				type: "POST",
				url: "../memberController?cmd=idCheck",
				data: {"memID":$("#memID").val()},
				
				success: function(data) {
					if($.trim(data)=="Y") {
						alert("사용가능");
						$("#isDuplicate").val("y");
					} else {
						alert("사용불가");
						$("#isDuplicate").val("");
					}				
				}
			});
		}
	});
	
	$("#logSubmit").click(function() {
		var logID = $("#memID").val();
		var logPass = $("#pwd").val();
		var formData = $("#id2").serialize();
		var formAction = $("#id2").attr("action");
		if (logID==""){
			alert("아이디를 입력하세요");
		} else if (logPass==""){
			alert("비밀번호를 입력하세요");
		} else {
			$.ajax({
				type: "POST",			
				url: formAction+"?cmd=loginMember",
				data: formData,
				success: function(data) {
					if($.trim(data)=="n") {
						alert("아이디가 틀립니다.");
					} else if($.trim(data)=="np") {
						alert("비밀번호가 틀립니다.");
					} else if($.trim(data)=="y"){						
						alert("로그인 성공 환영합니다.")
						location.replace('./main/main.jsp');
					}
				}
			});
		}
	});
	
	$("#goCal").click(function() {
		$.ajax({
			url: "../memberController?cmd=isLogin",
			success: function(data) {
				if($.trim(data)=="y") {
					location.replace('../cal/cal.jsp');
				} else {
					alert(data);
					alert("로그인하세요.");
					location.replace('index.jsp');
				}				
			}
		});
	})
		
	$("#deleteMember").click(function() {
		var logID = $("#memID").val();
		var logPass = $("#memPwd").val();
		var formData = $("#updateMember1").serialize();
		var formAction = $("#updateMember1").attr("action");
		var result = confirm('정말 탈퇴하시겠습니까?');
			$.ajax({
				type: "POST",			
				url: formAction+"?cmd=deleteMember",
				data: formData,
				success: function(data) {
					if($.trim(data)=="yes") {
						alert("탈퇴 성공");
						location.replace("index.jsp");
					}
									
				}
							
			});

	});

	$("#updateMember").click(function() {//button
		var result = confirm('정말 수정하시겠습니까?');
		var formData = $("#updateMember1").serialize(); // controller input data
		var formAction = $("#updateMember1").attr("action");// controller 주소,버튼//액션주소
		if (result){
			$.ajax({
				type: "POST",			
				url: formAction+"?cmd=updateMember",
				data: formData,
				success: function(data) {
					if($.trim(data)=="yes") {
						alert("수정 완료!");
						location.reload();
					} else {
						alert("수정실패");
					}
				}
			});
		} else {
			
		}
	});
	
	$("#selectAllSubmit").click(function() {
		var formAction = $("#selectMember1").attr("action");
		$.ajax({
			type: "POST",			
			url: formAction+"?cmd=selectAllMember",
			
			success: function(data) { 
				alert(data);
				if($.trim(data)!="") {
					var result = JSON.parse(data);
					var mem;
					alert("조회성공");
					
					for(var i=0;i<result.length; i++ ) {
						var id = result[i].ID;
						var password = result[i].password
						var name = result[i].name
						var phone = result[i].phone
						var address = result[i].address
							
						mem = id+ "\n" + password+ "\n"+ name+"\n" + phone+address;
					}
				
					alert(mem);

					$("#allResult").text(mem).css("color","red");					
				}else {
					alert("조회 실패!");
				}
			}
		});
	});
	 
	$("#selectSubmit").click(function() {
		var logID = $("#memID").val();
		var logPass = $("#memPwd").val();
		var formData = $("#selectMember1").serialize();
		var formAction = $("#selectMember1").attr("action");
			$.ajax({
				url : formAction+"?cmd=selectMember", 
				data : formData,
				success : function(data) {
					alert(data);
					var result = JSON.parse(data);
					alert(result.memID);
					if (logID==""){
						alert("아이디 입력하세요");
					} else if (logPass==""){
						alert("비밀번호를 력하세요");
					} else {
						
					}	
				}
			});
	});
	
	$("#logout").click(function() {
		var result = confirm('로그아웃 하시겠습니까?');
		if(result) {   
			$.ajax({type: "POST",
				url: "../memberController?cmd=logout",
				success: function() {
					location.replace('../index.jsp');		
			}
		});
		} 
	});
	

	
	$("#onSubmit").click(function() {
		var memID = $("#memID").val();
		var memPwd = $("#pwd").val();
		var formAction = $("#memForm").attr("action");
		var formData = $("#memForm").serialize();
		if (memID==""){
			alert("아이디를 입력하세요");
			return false;
		} else {
			if($("#isDuplicate").val() == "y") {
				$.ajax({
					type: "POST",			
					url: formAction+"?cmd=insertMember",
					data: formData,
					success: function(data) {
						if($.trim(data)=="yes") {
							alert("가입성공");
							location.replace("../index.jsp");
						} else {
							alert("가입실패");
						} 
					}
				});
			} else {
				alert("중복체크 요망");
			}
		}
	});
	
});