CREATE TABLE tb_mem (
	id  int NOT NULL,
	memID  varchar(20) NOT NULL,
	pwd  varchar(15) NOT NULL,
	name  varchar(15) NOT NULL,
	phone varchar(25) NOT NULL,
	address varchar(50) NOT NULL

);
SELECT * FROM tb_mem ORDER BY memID;
select * from tb_mem;

insert into TB_MEM (id,memID,pwd,name,phone,address);

values(seq_mem.nextval,'mama','asd','s','0','as');

ALTER TABLE tb_mem ADD PRIMARY KEY (id);

create sequence seq_mem
start with 1
increment by 1
minvalue 0
maxvalue 1000000;

DROP TABLE tb_mem;