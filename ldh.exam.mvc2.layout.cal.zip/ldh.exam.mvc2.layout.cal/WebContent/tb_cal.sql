CREATE TABLE tb_cal (
   id  int NOT NULL,
   op1  int NOT NULL,
   op  varchar(5) NOT NULL,
   op2  int NOT NULL,
   result  int NOT NULL
);


CREATE TABLE tb_msg (
   id  int NOT NULL,
   code  int NOT NULL,
   msg  varchar(30) NOT NULL

);
insert into tb_msg(id,code,msg) values('1','95','AddZeroException');
insert into tb_msg(id,code,msg) values('2','96','SubZeroException');
insert into tb_msg(id,code,msg) values('3','97','MulOneException');
insert into tb_msg(id,code,msg) values('4','98','DivOneException');

ALTER TABLE tb_cal ADD PRIMARY KEY (id);
ALTER TABLE tb_msg ADD PRIMARY KEY (id);

select * from tb_cal;

drop table tb_cal;
drop table tb_msg;

create sequence seq_cal
start with 1
increment by 1
maxvalue 10000000;

select seq_log.currval from dual;

select * from tb_cal;

drop sequence seq_log;

insert into Cal values(seq_log.nextval, '3','add','5','8');


delete tb_cal;